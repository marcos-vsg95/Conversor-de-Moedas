function converterMoeda() {
  var val1 = parseFloat(document.getElementById("val1").value);
  var moeda1 = document.getElementById("moeda1").value;
  var moeda2 = document.getElementById("moeda2").value;
  var val2 = document.getElementById("val2");


  if (isNaN(val1) || val1 <= 0) {
    alert("Por favor, insira um valor válido para conversão.");
    return;
  }

  if (moeda1 === moeda2) {
    alert("As moedas de origem e destino são iguais. Não é necessário converter.");
    return;
  }

  switch (moeda1) {
    case 'dolar':
      if (moeda2 === 'real') {
        val2.value = (val1 * 5.25).toFixed(2);
      } else if (moeda2 === 'euro') {
        val2.value = (val1 * 0.84).toFixed(2);
      } else if (moeda2 === 'libra') {
        val2.value = (val1 * 0.73).toFixed(2);
      } else if (moeda2 === 'peso') {
        val2.value = (val1 * 109.72).toFixed(2);
      }
      break;
    case 'euro':
      if (moeda2 === 'real') {
        val2.value = (val1 * 6.20).toFixed(2);
      } else if (moeda2 === 'dolar') {
        val2.value = (val1 * 1.19).toFixed(2);
      } else if (moeda2 === 'libra') {
        val2.value = (val1 * 0.87).toFixed(2);
      } else if (moeda2 === 'peso') {
        val2.value = (val1 * 130.41).toFixed(2);
      }
      break;
    case 'real':
      if (moeda2 === 'dolar') {
        val2.value = (val1 / 5.25).toFixed(2);
      } else if (moeda2 === 'euro') {
        val2.value = (val1 / 6.20).toFixed(2);
      } else if (moeda2 === 'libra') {
        val2.value = (val1 / 7.13).toFixed(2);
      } else if (moeda2 === 'peso') {
        val2.value = (val1 / 0.057).toFixed(2);
      }
      break;
    case 'peso':
      if (moeda2 === 'real') {
        val2.value = (val1 * 0.057).toFixed(2);
      } else if (moeda2 === 'dolar') {
        val2.value = (val1 * 0.0091).toFixed(2);
      } else if (moeda2 === 'euro') {
        val2.value = (val1 * 0.0077).toFixed(2);
      } else if (moeda2 === 'libra') {
        val2.value = (val1 * 0.0067).toFixed(2);
      }
      break;
    case 'libra':
      if (moeda2 === 'real') {
        val2.value = (val1 * 7.13).toFixed(2);
      } else if (moeda2 === 'dolar') {
        val2.value = (val1 * 1.37).toFixed(2);
      } else if (moeda2 === 'euro') {
        val2.value = (val1 * 1.15).toFixed(2);
      } else if (moeda2 === 'peso') {
        val2.value = (val1 * 150.19).toFixed(2);
      }
      break;
    default:
      break;
  }


}